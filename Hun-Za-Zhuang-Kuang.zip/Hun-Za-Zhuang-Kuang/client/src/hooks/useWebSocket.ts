import { useEffect, useState, useRef, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";

export type WebSocketMessage = {
  type: string;
  payload: any;
};

type WebSocketState = {
  connected: boolean;
  lastMessage: WebSocketMessage | null;
  currentOccupancy: any;
  recentFlow: any[];
  flowSummary: any;
  sensorStatuses: any[];
  lastUpdated: Date | null;
};

export function useWebSocket() {
  const [state, setState] = useState<WebSocketState>({
    connected: false,
    lastMessage: null,
    currentOccupancy: null,
    recentFlow: [],
    flowSummary: { entrances: 0, exits: 0, net: 0 },
    sensorStatuses: [],
    lastUpdated: null,
  });
  
  const socketRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();
  
  // Reconnect attempts
  const reconnectTimeoutRef = useRef<number | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const maxReconnectAttempts = 5;
  
  const connect = useCallback(() => {
    // Clear any existing connection
    if (socketRef.current) {
      socketRef.current.close();
    }
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;
    
    socket.addEventListener("open", () => {
      setState(prev => ({ ...prev, connected: true }));
      reconnectAttemptsRef.current = 0;
      toast({
        title: "接続完了",
        description: "リアルタイム更新の接続が確立されました。",
        duration: 3000,
      });
    });
    
    socket.addEventListener("message", (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketMessage;
        
        if (message.type === "initial_data" || message.type === "update") {
          const { currentOccupancy, recentFlow, flowSummary, sensorStatuses } = message.payload;
          
          setState(prev => ({
            ...prev,
            lastMessage: message,
            currentOccupancy: currentOccupancy || prev.currentOccupancy,
            recentFlow: recentFlow || prev.recentFlow,
            flowSummary: flowSummary || prev.flowSummary,
            sensorStatuses: sensorStatuses || prev.sensorStatuses,
            lastUpdated: new Date(),
          }));
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    });
    
    socket.addEventListener("close", () => {
      setState(prev => ({ ...prev, connected: false }));
      
      // Attempt to reconnect
      if (reconnectAttemptsRef.current < maxReconnectAttempts) {
        reconnectAttemptsRef.current += 1;
        const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
        
        reconnectTimeoutRef.current = window.setTimeout(() => {
          connect();
        }, delay);
        
        toast({
          title: "接続が切断されました",
          description: `再接続を試みています... (${reconnectAttemptsRef.current}/${maxReconnectAttempts})`,
          variant: "destructive",
          duration: 3000,
        });
      } else {
        toast({
          title: "接続できません",
          description: "リアルタイム更新に接続できません。ページを再読み込みしてください。",
          variant: "destructive",
          duration: Infinity,
        });
      }
    });
    
    socket.addEventListener("error", (error) => {
      console.error("WebSocket error:", error);
    });
    
  }, [toast]);
  
  useEffect(() => {
    connect();
    
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connect]);
  
  // Function to send a message to the server
  const sendMessage = useCallback((type: string, payload: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type, payload }));
      return true;
    }
    return false;
  }, []);
  
  return {
    ...state,
    sendMessage,
    isConnected: state.connected,
  };
}
