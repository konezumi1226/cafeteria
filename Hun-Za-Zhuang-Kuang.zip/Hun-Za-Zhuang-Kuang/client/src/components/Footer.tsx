import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white py-6 mt-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-lg font-medium mb-2">学食混雑状況モニター</h2>
            <p className="text-sm text-neutral-400">リアルタイムで学食の混雑状況を確認できるシステム</p>
          </div>
          
          <div className="flex flex-col text-center md:text-right">
            <span className="text-sm text-neutral-400">開発・運用</span>
            <span className="text-sm">情報システム学科</span>
            <Link href="/admin" className="text-sm text-primary-300 hover:underline mt-1">
              管理画面
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
