import { formatTime } from "@/lib/calculateCongestion";
import { ChevronsRight, LogIn, LogOut } from "lucide-react";

interface EntranceExitMonitorProps {
  flowSummary?: {
    entrances: number;
    exits: number;
    net: number;
  };
  recentFlow?: Array<{
    id: number;
    timestamp: string;
    isEntrance: boolean;
    count: number;
  }>;
  timeFrame?: number; // minutes
}

export default function EntranceExitMonitor({ 
  flowSummary = { entrances: 0, exits: 0, net: 0 },
  recentFlow = [],
  timeFrame = 10
}: EntranceExitMonitorProps) {
  return (
    <section className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-primary text-white">
        <h2 className="text-lg font-medium">入退室モニター</h2>
      </div>
      <div className="p-6">
        <div className="flex justify-between mb-6">
          <div className="text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-2 rounded-full bg-green-100">
              <LogIn className="text-success text-3xl" />
            </div>
            <span className="text-sm text-neutral-700">入室</span>
            <div className="mt-1 text-2xl font-light">
              <span className="pulse-animation inline-block">+{flowSummary.entrances}</span>
              <span className="text-sm text-neutral-500">/{timeFrame}分</span>
            </div>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-2 flex justify-center items-center">
              <ChevronsRight className="text-neutral-700 text-4xl" />
            </div>
            <span className="text-sm text-neutral-700">収支</span>
            <div className="mt-1 text-2xl font-light">
              <span className={flowSummary.net > 0 ? "text-warning" : (flowSummary.net < 0 ? "text-success" : "text-neutral-500")}>
                {flowSummary.net > 0 ? "+" : ""}{flowSummary.net}
              </span>
              <span className="text-sm text-neutral-500">/{timeFrame}分</span>
            </div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-2 rounded-full bg-red-100">
              <LogOut className="text-danger text-3xl" />
            </div>
            <span className="text-sm text-neutral-700">退室</span>
            <div className="mt-1 text-2xl font-light">
              <span className="pulse-animation inline-block">-{flowSummary.exits}</span>
              <span className="text-sm text-neutral-500">/{timeFrame}分</span>
            </div>
          </div>
        </div>
        
        <div className="bg-neutral-100 rounded-lg p-4">
          <h3 className="text-sm font-medium text-neutral-700 mb-2">最近の動き</h3>
          <ul className="space-y-2 max-h-48 overflow-y-auto">
            {recentFlow.length > 0 ? (
              recentFlow.map((event) => (
                <li key={event.id} className="text-sm flex items-center py-1 border-b border-neutral-200 last:border-b-0">
                  {event.isEntrance ? (
                    <LogIn className="h-4 w-4 mr-2 text-success" />
                  ) : (
                    <LogOut className="h-4 w-4 mr-2 text-danger" />
                  )}
                  <span>
                    {event.count}名{event.isEntrance ? '入室' : '退室'}
                  </span>
                  <span className="ml-auto text-neutral-500 text-xs">
                    {formatTime(new Date(event.timestamp))}
                  </span>
                </li>
              ))
            ) : (
              <li className="text-sm py-1 text-center text-neutral-500">
                まだ記録されたデータがありません
              </li>
            )}
          </ul>
        </div>
      </div>
    </section>
  );
}
