import { useEffect, useRef } from 'react';
import { 
  calculateCongestionLevel, 
  getCongestionName, 
  getCongestionColorClass,
  CongestionLevel
} from "@/lib/calculateCongestion";
import Chart from 'chart.js/auto';
import { Info } from 'lucide-react';

interface PeakTimesEstimationProps {
  hourlyData?: Array<{ hour: number; avgCount: number }>;
  capacity?: number;
  currentOccupancy?: number;
}

export default function PeakTimesEstimation({ 
  hourlyData = [],
  capacity = 200,
  currentOccupancy = 0
}: PeakTimesEstimationProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  // Find peak time
  const peakHour = hourlyData.reduce(
    (max, current) => (current.avgCount > max.avgCount ? current : max),
    { hour: 0, avgCount: 0 }
  );
  
  const peakHourFormatted = formatHourRange(peakHour.hour);
  
  // Calculate current congestion level
  const congestionLevel = calculateCongestionLevel(currentOccupancy, capacity);
  const congestionName = getCongestionName(congestionLevel);
  
  // Calculate comparison to average
  const currentHour = new Date().getHours();
  const currentHourData = hourlyData.find(data => data.hour === currentHour);
  const comparisonPercentage = currentHourData 
    ? Math.round(((currentOccupancy - currentHourData.avgCount) / currentHourData.avgCount) * 100) 
    : 0;
  
  useEffect(() => {
    if (chartRef.current && hourlyData.length > 0) {
      const ctx = chartRef.current.getContext('2d');
      
      if (!ctx) return;
      
      // Destroy existing chart if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
      
      // Prepare data for chart
      const labels = Array.from({ length: 13 }, (_, i) => `${i + 8}:00`); // 8:00 to 20:00
      
      const data = Array.from({ length: 13 }, (_, i) => {
        const hour = i + 8;
        const hourData = hourlyData.find(d => d.hour === hour);
        return hourData ? hourData.avgCount : 0;
      });
      
      // Calculate percentages for color determination
      const percentages = data.map(count => (count / capacity) * 100);
      
      // Determine colors based on congestion levels
      const backgroundColors = percentages.map(percentage => {
        if (percentage < 40) return 'rgba(76, 175, 80, 0.8)'; // Green for low congestion
        if (percentage < 80) return 'rgba(255, 152, 0, 0.8)'; // Orange for medium congestion
        return 'rgba(244, 67, 54, 0.8)'; // Red for high congestion
      });
      
      // Create chart
      chartInstance.current = new Chart(ctx, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: '平均利用者数',
            data,
            backgroundColor: backgroundColors,
            borderColor: backgroundColors.map(color => color.replace('0.8', '1')),
            borderWidth: 1,
            borderRadius: 4,
            barThickness: 20,
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              max: capacity,
              title: {
                display: true,
                text: '利用者数'
              }
            },
            x: {
              title: {
                display: true,
                text: '時間'
              }
            }
          },
          plugins: {
            tooltip: {
              callbacks: {
                label: (context) => {
                  const value = context.raw as number;
                  const percentage = Math.round((value / capacity) * 100);
                  return [`利用者数: ${value}人`, `使用率: ${percentage}%`];
                }
              }
            },
            legend: {
              display: false
            }
          }
        }
      });
      
      // Add current time indicator
      const currentTime = new Date();
      const hour = currentTime.getHours();
      const minute = currentTime.getMinutes();
      
      if (hour >= 8 && hour <= 20) {
        const position = (hour - 8) + (minute / 60);
        const totalBars = 13;
        const positionPercentage = position / totalBars;
        
        const originalDraw = chartInstance.current.draw;
        chartInstance.current.draw = function() {
          originalDraw.apply(this, arguments);
          
          const chartArea = this.chartArea;
          const ctx = this.ctx;
          
          if (!ctx) return;
          
          const xPos = chartArea.left + (chartArea.right - chartArea.left) * positionPercentage;
          
          // Draw vertical line
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(xPos, chartArea.top);
          ctx.lineTo(xPos, chartArea.bottom);
          ctx.lineWidth = 2;
          ctx.strokeStyle = 'red';
          ctx.stroke();
          
          // Draw label
          ctx.fillStyle = 'red';
          ctx.fillRect(xPos - 20, chartArea.top - 20, 40, 20);
          ctx.fillStyle = 'white';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.font = '12px sans-serif';
          ctx.fillText('現在', xPos, chartArea.top - 10);
          
          ctx.restore();
        };
      }
      
      return () => {
        if (chartInstance.current) {
          chartInstance.current.destroy();
        }
      };
    }
  }, [hourlyData, capacity]);
  
  return (
    <section className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-primary text-white">
        <h2 className="text-lg font-medium">時間帯別の混雑予測</h2>
      </div>
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <span className="text-sm text-neutral-700">今日の混雑ピーク</span>
            <div className="text-xl font-light">{peakHourFormatted}</div>
          </div>
          <div className="text-right">
            <span className="text-sm text-neutral-700">現在の混雑度</span>
            <div className={`text-xl font-light text-${getCongestionColorClass(congestionLevel, 'text')}`}>
              {congestionName}
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <div className="min-w-full">
            {comparisonPercentage !== 0 && (
              <div className="bg-neutral-100 p-3 rounded-lg mb-4 flex items-center">
                <Info className="text-primary mr-2 h-5 w-5" />
                <span className="text-sm">
                  今日は通常より
                  <span className={`font-medium ${comparisonPercentage > 0 ? 'text-danger' : 'text-success'}`}>
                    {comparisonPercentage > 0 ? '+' : ''}{comparisonPercentage}%
                  </span>
                  {comparisonPercentage > 0 ? '混雑しています' : '空いています'}
                </span>
              </div>
            )}
            
            <div className="chart-container bg-white h-64">
              <canvas ref={chartRef}></canvas>
            </div>
            
            <div className="mt-4 flex justify-center space-x-4 text-sm">
              <div className="flex items-center">
                <span className="inline-block w-3 h-3 bg-success rounded-sm mr-1"></span>
                <span>空いている</span>
              </div>
              <div className="flex items-center">
                <span className="inline-block w-3 h-3 bg-warning rounded-sm mr-1"></span>
                <span>やや混雑</span>
              </div>
              <div className="flex items-center">
                <span className="inline-block w-3 h-3 bg-danger rounded-sm mr-1"></span>
                <span>非常に混雑</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function formatHourRange(hour: number): string {
  const start = `${hour}:00`;
  const end = `${hour + 1}:30`;
  return `${start} - ${end}`;
}
