import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { formatTime } from '@/lib/calculateCongestion';
import { ArrowRight } from 'lucide-react';

interface SystemStatusProps {
  sensorStatuses?: Array<{
    id: number;
    name: string;
    isOnline: boolean;
    lastUpdated: string;
  }>;
}

export default function SystemStatus({ sensorStatuses = [] }: SystemStatusProps) {
  // Memory usage is simulated as this would typically come from a system monitoring endpoint
  const memoryUsage = {
    used: 583,
    total: 1800,
    percentage: 32
  };
  
  // Get formatted sensor data
  const entranceSensor = sensorStatuses.find(sensor => sensor.name === 'entrance_sensor') || {
    id: 0,
    name: 'entrance_sensor',
    isOnline: true,
    lastUpdated: new Date().toISOString()
  };
  
  const exitSensor = sensorStatuses.find(sensor => sensor.name === 'exit_sensor') || {
    id: 0,
    name: 'exit_sensor',
    isOnline: true,
    lastUpdated: new Date().toISOString()
  };
  
  // Calculate time differences
  const getTimeAgo = (dateString: string): string => {
    const now = new Date();
    const date = new Date(dateString);
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return '数秒前';
    if (diffMins === 1) return '1分前';
    return `${diffMins}分前`;
  };
  
  return (
    <section>
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-primary text-white">
          <h2 className="text-lg font-medium">システム状況</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center p-3 border border-neutral-200 rounded-md">
              <div className={`w-3 h-3 ${entranceSensor.isOnline ? 'bg-success' : 'bg-danger'} rounded-full mr-3`}></div>
              <div>
                <span className="text-sm font-medium">入口センサー</span>
                <span className="text-xs text-neutral-500 block">
                  {entranceSensor.isOnline ? '正常に動作中' : '接続エラー'}
                </span>
              </div>
              <span className="text-xs text-neutral-500 ml-auto">
                更新: {getTimeAgo(entranceSensor.lastUpdated)}
              </span>
            </div>
            
            <div className="flex items-center p-3 border border-neutral-200 rounded-md">
              <div className={`w-3 h-3 ${exitSensor.isOnline ? 'bg-success' : 'bg-danger'} rounded-full mr-3`}></div>
              <div>
                <span className="text-sm font-medium">出口センサー</span>
                <span className="text-xs text-neutral-500 block">
                  {exitSensor.isOnline ? '正常に動作中' : '接続エラー'}
                </span>
              </div>
              <span className="text-xs text-neutral-500 ml-auto">
                更新: {getTimeAgo(exitSensor.lastUpdated)}
              </span>
            </div>
            
            <div className="flex items-center p-3 border border-neutral-200 rounded-md">
              <div className="w-3 h-3 bg-success rounded-full mr-3"></div>
              <div>
                <span className="text-sm font-medium">データベース</span>
                <span className="text-xs text-neutral-500 block">接続中</span>
              </div>
              <span className="text-xs text-neutral-500 ml-auto">更新: 2分前</span>
            </div>
            
            <div className="flex items-center p-3 border border-neutral-200 rounded-md">
              <div className="w-3 h-3 bg-success rounded-full mr-3"></div>
              <div>
                <span className="text-sm font-medium">メモリ使用率</span>
                <span className="text-xs text-neutral-500 block">
                  {memoryUsage.percentage}% ({memoryUsage.used}MB / {memoryUsage.total}GB)
                </span>
              </div>
              <span className="text-xs text-neutral-500 ml-auto">更新: 3分前</span>
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <Link href="/admin" className="text-sm text-primary flex items-center hover:underline">
              <span>管理画面</span>
              <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
