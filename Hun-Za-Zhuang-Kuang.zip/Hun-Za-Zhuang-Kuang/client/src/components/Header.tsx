import { useLocation } from "wouter";
import { formatLastUpdated } from "@/lib/calculateCongestion";

interface HeaderProps {
  lastUpdated?: Date | null;
}

export default function Header({ lastUpdated }: HeaderProps = {}) {
  const [location] = useLocation();
  const isAdmin = location === "/admin";
  
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-medium md:text-2xl">
            学食混雑状況モニター
            {isAdmin && <span className="ml-2 text-sm bg-white text-primary px-2 py-0.5 rounded-full">管理画面</span>}
          </h1>
          <div className="flex items-center space-x-2">
            {lastUpdated && (
              <span className="hidden md:inline text-sm">
                {formatLastUpdated(lastUpdated)}
              </span>
            )}
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
            </span>
            <span className="text-sm">リアルタイム</span>
          </div>
        </div>
      </div>
    </header>
  );
}
