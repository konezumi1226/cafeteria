import { 
  calculateCongestionLevel, 
  getCongestionName, 
  getCongestionColorClass, 
  getEstimatedWaitTime,
  CongestionLevel
} from "@/lib/calculateCongestion";

interface CurrentStatusOverviewProps {
  currentCount?: number;
  capacity?: number;
}

export default function CurrentStatusOverview({ 
  currentCount = 0, 
  capacity = 200 
}: CurrentStatusOverviewProps) {
  const percentage = capacity > 0 ? Math.round((currentCount / capacity) * 100) : 0;
  const congestionLevel = calculateCongestionLevel(currentCount, capacity);
  const congestionName = getCongestionName(congestionLevel);
  const waitTime = getEstimatedWaitTime(currentCount, capacity);
  
  return (
    <section className="mb-8">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-primary text-white">
          <h2 className="text-lg font-medium">現在の混雑状況</h2>
        </div>
        
        <div className={`p-6 congestion-${congestionLevel}`} style={{
          backgroundColor: getCongestionBackgroundColor(congestionLevel)
        }}>
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-center md:text-left mb-4 md:mb-0">
              <span className="block text-4xl font-light">{currentCount}</span>
              <span className="text-sm text-neutral-700">現在の利用者数</span>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="relative w-32 h-32 mb-2">
                <div className="absolute inset-0 rounded-full border-8 border-neutral-200"></div>
                <CircularProgress 
                  percentage={percentage} 
                  color={getCongestionColorHex(congestionLevel)} 
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className={`text-3xl font-light text-${getCongestionColorClass(congestionLevel, 'text')}`}>
                    {percentage}%
                  </span>
                </div>
              </div>
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-${getCongestionColorClass(congestionLevel)} text-white`}>
                {congestionName}
              </span>
            </div>
            
            <div className="flex flex-col space-y-2 text-center md:text-right mt-4 md:mt-0">
              <div>
                <span className="text-sm text-neutral-700">収容可能人数</span>
                <span className="block text-2xl font-light">{capacity}</span>
              </div>
              <div>
                <span className="text-sm text-neutral-700">待ち時間の目安</span>
                <span className="block text-2xl font-light">{waitTime}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

interface CircularProgressProps {
  percentage: number;
  color: string;
}

function CircularProgress({ percentage, color }: CircularProgressProps) {
  // Calculate the circumference
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  
  // Calculate the strokeDashoffset based on percentage
  const offset = circumference - (percentage / 100) * circumference;
  
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <svg width="100%" height="100%" viewBox="0 0 100 100">
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="8"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform="rotate(-90 50 50)"
        />
      </svg>
    </div>
  );
}

function getCongestionBackgroundColor(level: CongestionLevel): string {
  switch (level) {
    case 'low':
      return 'rgba(76, 175, 80, 0.2)';
    case 'medium':
      return 'rgba(255, 152, 0, 0.2)';
    case 'high':
      return 'rgba(244, 67, 54, 0.2)';
    default:
      return 'transparent';
  }
}

function getCongestionColorHex(level: CongestionLevel): string {
  switch (level) {
    case 'low':
      return '#4CAF50';
    case 'medium':
      return '#FF9800';
    case 'high':
      return '#F44336';
    default:
      return '#9E9E9E';
  }
}
