import { useState } from "react";
import { useWebSocket } from "@/hooks/useWebSocket";
import Header from "@/components/Header";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { ArrowLeft, Database, RefreshCw, GitCommit, Users, AlertTriangle } from "lucide-react";

export default function Admin() {
  const [entranceCount, setEntranceCount] = useState(1);
  const [exitCount, setExitCount] = useState(1);
  const [manualCount, setManualCount] = useState("");
  const [capacityValue, setCapacityValue] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  
  const { toast } = useToast();
  const { currentOccupancy, lastUpdated, sensorStatuses, isConnected, sendMessage } = useWebSocket();
  
  // Simulate entrance sensor trigger
  const handleEntranceSimulation = async () => {
    setIsProcessing(true);
    try {
      await apiRequest("POST", "/api/flow", { 
        isEntrance: true, 
        count: parseInt(entranceCount.toString()) 
      });
      
      // Alternative WebSocket approach
      // sendMessage("sensor_data", { 
      //   sensor: "entrance", 
      //   count: parseInt(entranceCount.toString())
      // });
      
      toast({
        title: "入室イベント送信",
        description: `${entranceCount}名の入室を記録しました。`,
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/occupancy/current'] });
      queryClient.invalidateQueries({ queryKey: ['/api/flow/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/flow/summary'] });
      
    } catch (error) {
      toast({
        title: "エラー",
        description: "入室イベントの送信に失敗しました。",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Simulate exit sensor trigger
  const handleExitSimulation = async () => {
    setIsProcessing(true);
    try {
      await apiRequest("POST", "/api/flow", { 
        isEntrance: false, 
        count: parseInt(exitCount.toString()) 
      });
      
      // Alternative WebSocket approach
      // sendMessage("sensor_data", { 
      //   sensor: "exit", 
      //   count: parseInt(exitCount.toString())
      // });
      
      toast({
        title: "退室イベント送信",
        description: `${exitCount}名の退室を記録しました。`,
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/occupancy/current'] });
      queryClient.invalidateQueries({ queryKey: ['/api/flow/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/flow/summary'] });
      
    } catch (error) {
      toast({
        title: "エラー",
        description: "退室イベントの送信に失敗しました。",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Manual update of occupancy count
  const handleManualUpdate = async () => {
    if (!manualCount) {
      toast({
        title: "エラー",
        description: "有効な人数を入力してください。",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    try {
      const count = parseInt(manualCount);
      const capacity = currentOccupancy?.capacity || 200;
      
      await apiRequest("POST", "/api/occupancy", { 
        count, 
        capacity 
      });
      
      // Alternative WebSocket approach
      // sendMessage("manual_update", { 
      //   type: "occupancy", 
      //   count
      // });
      
      toast({
        title: "手動更新",
        description: `利用者数を${count}名に更新しました。`,
      });
      
      // Clear input field
      setManualCount("");
      
      // Invalidate relevant query
      queryClient.invalidateQueries({ queryKey: ['/api/occupancy/current'] });
      
    } catch (error) {
      toast({
        title: "エラー",
        description: "利用者数の更新に失敗しました。",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Update capacity
  const handleCapacityUpdate = async () => {
    if (!capacityValue) {
      toast({
        title: "エラー",
        description: "有効な収容人数を入力してください。",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    try {
      const capacity = parseInt(capacityValue);
      const count = currentOccupancy?.count || 0;
      
      await apiRequest("POST", "/api/occupancy", { 
        count, 
        capacity 
      });
      
      toast({
        title: "収容人数更新",
        description: `収容人数を${capacity}名に更新しました。`,
      });
      
      // Clear input field
      setCapacityValue("");
      
      // Invalidate relevant query
      queryClient.invalidateQueries({ queryKey: ['/api/occupancy/current'] });
      
    } catch (error) {
      toast({
        title: "エラー",
        description: "収容人数の更新に失敗しました。",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Toggle sensor status
  const handleToggleSensor = async (sensorName: string, isOnline: boolean) => {
    setIsProcessing(true);
    try {
      await apiRequest("POST", "/api/sensors/status", { 
        name: sensorName, 
        isOnline 
      });
      
      toast({
        title: "センサー状態更新",
        description: `${sensorName === 'entrance_sensor' ? '入口' : '出口'}センサーを${isOnline ? 'オンライン' : 'オフライン'}に設定しました。`,
      });
      
      // Invalidate relevant query
      queryClient.invalidateQueries({ queryKey: ['/api/sensors/status'] });
      
    } catch (error) {
      toast({
        title: "エラー",
        description: "センサー状態の更新に失敗しました。",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Get sensor statuses
  const entranceSensor = sensorStatuses.find(s => s.name === 'entrance_sensor');
  const exitSensor = sensorStatuses.find(s => s.name === 'exit_sensor');
  
  return (
    <div className="bg-gray-50 min-h-screen">
      <Header lastUpdated={lastUpdated} />
      
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6 flex items-center">
          <Link href="/" className="text-primary hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            モニター画面に戻る
          </Link>
          
          <div className="ml-auto flex items-center">
            <span className={`inline-flex h-3 w-3 rounded-full mr-2 ${isConnected ? 'bg-success' : 'bg-danger'}`}></span>
            <span className="text-sm text-neutral-600">
              {isConnected ? 'リアルタイム接続中' : '接続が切断されました'}
            </span>
          </div>
        </div>
        
        <div className="mb-6">
          <Card>
            <CardHeader>
              <CardTitle>現在の状況</CardTitle>
              <CardDescription>現在のカフェテリア利用状況</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="flex flex-col">
                  <span className="text-sm text-neutral-500">現在の利用者数</span>
                  <span className="text-3xl font-light">{currentOccupancy?.count || 0}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm text-neutral-500">収容人数</span>
                  <span className="text-3xl font-light">{currentOccupancy?.capacity || 200}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm text-neutral-500">使用率</span>
                  <span className="text-3xl font-light">
                    {currentOccupancy 
                      ? Math.round((currentOccupancy.count / currentOccupancy.capacity) * 100)
                      : 0}%
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="simulation">
          <TabsList className="mb-6">
            <TabsTrigger value="simulation">センサーシミュレーション</TabsTrigger>
            <TabsTrigger value="manual">手動データ更新</TabsTrigger>
            <TabsTrigger value="system">システム管理</TabsTrigger>
          </TabsList>
          
          <TabsContent value="simulation">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>入口センサーシミュレーション</CardTitle>
                  <CardDescription>入室イベントを手動でトリガーする</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="entrance-count">入室人数</Label>
                        <Input
                          id="entrance-count"
                          type="number"
                          min="1"
                          max="50"
                          value={entranceCount}
                          onChange={(e) => setEntranceCount(parseInt(e.target.value) || 1)}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button 
                          className="w-full" 
                          onClick={handleEntranceSimulation}
                          disabled={isProcessing || !entranceSensor?.isOnline}
                        >
                          {isProcessing ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
                          入室イベント送信
                        </Button>
                      </div>
                    </div>
                    
                    {!entranceSensor?.isOnline && (
                      <div className="text-sm text-danger flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-1" />
                        入口センサーはオフラインです
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>出口センサーシミュレーション</CardTitle>
                  <CardDescription>退室イベントを手動でトリガーする</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="exit-count">退室人数</Label>
                        <Input
                          id="exit-count"
                          type="number"
                          min="1"
                          max="50"
                          value={exitCount}
                          onChange={(e) => setExitCount(parseInt(e.target.value) || 1)}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button 
                          className="w-full" 
                          onClick={handleExitSimulation}
                          disabled={isProcessing || !exitSensor?.isOnline}
                        >
                          {isProcessing ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
                          退室イベント送信
                        </Button>
                      </div>
                    </div>
                    
                    {!exitSensor?.isOnline && (
                      <div className="text-sm text-danger flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-1" />
                        出口センサーはオフラインです
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="manual">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>利用者数の手動更新</CardTitle>
                  <CardDescription>利用者数を直接指定して更新する</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="manual-count">利用者数</Label>
                        <Input
                          id="manual-count"
                          type="number"
                          min="0"
                          max={currentOccupancy?.capacity || 200}
                          value={manualCount}
                          onChange={(e) => setManualCount(e.target.value)}
                          placeholder="例: 120"
                        />
                      </div>
                      <div className="flex items-end">
                        <Button 
                          className="w-full" 
                          onClick={handleManualUpdate}
                          disabled={isProcessing}
                        >
                          {isProcessing ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
                          利用者数更新
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="text-sm text-neutral-500">
                  <Users className="h-4 w-4 mr-1" />
                  現在値: {currentOccupancy?.count || 0}名
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>収容人数の設定</CardTitle>
                  <CardDescription>カフェテリアの最大収容人数を設定する</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="capacity">収容人数</Label>
                        <Input
                          id="capacity"
                          type="number"
                          min="1"
                          max="1000"
                          value={capacityValue}
                          onChange={(e) => setCapacityValue(e.target.value)}
                          placeholder="例: 200"
                        />
                      </div>
                      <div className="flex items-end">
                        <Button 
                          className="w-full" 
                          onClick={handleCapacityUpdate}
                          disabled={isProcessing}
                        >
                          {isProcessing ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
                          収容人数更新
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="text-sm text-neutral-500">
                  <Database className="h-4 w-4 mr-1" />
                  現在値: {currentOccupancy?.capacity || 200}名
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="system">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>センサー制御</CardTitle>
                  <CardDescription>各センサーの状態を管理する</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="entrance-sensor" className="text-base">入口センサー</Label>
                        <p className="text-sm text-neutral-500">入室イベントを検知するセンサー</p>
                      </div>
                      <Switch
                        id="entrance-sensor"
                        checked={entranceSensor?.isOnline || false}
                        onCheckedChange={(checked) => handleToggleSensor('entrance_sensor', checked)}
                        disabled={isProcessing}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="exit-sensor" className="text-base">出口センサー</Label>
                        <p className="text-sm text-neutral-500">退室イベントを検知するセンサー</p>
                      </div>
                      <Switch
                        id="exit-sensor"
                        checked={exitSensor?.isOnline || false}
                        onCheckedChange={(checked) => handleToggleSensor('exit_sensor', checked)}
                        disabled={isProcessing}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>システム情報</CardTitle>
                  <CardDescription>システムの状態とバージョン情報</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-neutral-700">接続状態:</span>
                      <span className={`text-sm ${isConnected ? 'text-success' : 'text-danger'}`}>
                        {isConnected ? 'オンライン' : 'オフライン'}
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm text-neutral-700">最終更新:</span>
                      <span className="text-sm">
                        {lastUpdated ? new Date(lastUpdated).toLocaleString('ja-JP') : '未更新'}
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm text-neutral-700">バージョン:</span>
                      <span className="text-sm">1.0.0</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm text-neutral-700">最終デプロイ:</span>
                      <span className="text-sm flex items-center">
                        <GitCommit className="h-3 w-3 mr-1" />
                        {new Date().toLocaleDateString('ja-JP')}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
