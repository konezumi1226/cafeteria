import { useWebSocket } from "@/hooks/useWebSocket";
import Header from "@/components/Header";
import CurrentStatusOverview from "@/components/CurrentStatusOverview";
import EntranceExitMonitor from "@/components/EntranceExitMonitor";
import PeakTimesEstimation from "@/components/PeakTimesEstimation";
import HistoricalTrends from "@/components/HistoricalTrends";
import SystemStatus from "@/components/SystemStatus";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  // Connect to WebSocket for real-time updates
  const { 
    currentOccupancy,
    recentFlow,
    flowSummary,
    sensorStatuses,
    lastUpdated,
    isConnected
  } = useWebSocket();
  
  // Fetch hourly pattern data
  const { data: hourlyPattern } = useQuery({
    queryKey: ['/api/occupancy/daily-pattern'],
  });
  
  return (
    <div className="bg-gray-50 min-h-screen">
      <Header lastUpdated={lastUpdated} />
      
      <div className="container mx-auto px-4 py-6">
        <CurrentStatusOverview
          currentCount={currentOccupancy?.count}
          capacity={currentOccupancy?.capacity}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <EntranceExitMonitor
            flowSummary={flowSummary}
            recentFlow={recentFlow}
          />
          
          <PeakTimesEstimation
            hourlyData={hourlyPattern}
            capacity={currentOccupancy?.capacity}
            currentOccupancy={currentOccupancy?.count}
          />
        </div>
        
        <HistoricalTrends />
        
        <SystemStatus sensorStatuses={sensorStatuses} />
      </div>
    </div>
  );
}
