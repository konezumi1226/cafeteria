export type CongestionLevel = 'low' | 'medium' | 'high';

export function calculateCongestionLevel(count: number, capacity: number): CongestionLevel {
  const percentage = (count / capacity) * 100;
  
  if (percentage < 40) {
    return 'low';
  } else if (percentage < 80) {
    return 'medium';
  } else {
    return 'high';
  }
}

export function getCongestionName(level: CongestionLevel): string {
  switch (level) {
    case 'low':
      return '空いています';
    case 'medium':
      return 'やや混雑';
    case 'high':
      return '非常に混雑';
    default:
      return '';
  }
}

export function getCongestionColor(level: CongestionLevel): string {
  switch (level) {
    case 'low':
      return 'success';
    case 'medium':
      return 'warning';
    case 'high':
      return 'danger';
    default:
      return '';
  }
}

export function getCongestionColorClass(level: CongestionLevel, type: 'bg' | 'text' | 'border' = 'bg'): string {
  switch (level) {
    case 'low':
      return `${type}-success`;
    case 'medium':
      return `${type}-warning`;
    case 'high':
      return `${type}-danger`;
    default:
      return '';
  }
}

export function getEstimatedWaitTime(count: number, capacity: number): string {
  const percentage = (count / capacity) * 100;
  
  if (percentage < 40) {
    return 'ほぼなし';
  } else if (percentage < 60) {
    return '約5分';
  } else if (percentage < 80) {
    return '約10分';
  } else if (percentage < 90) {
    return '約15分';
  } else {
    return '20分以上';
  }
}

export function formatTime(date: Date): string {
  return date.toLocaleTimeString('ja-JP', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

export function formatLastUpdated(date: Date): string {
  return `最終更新: ${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日 ${formatTime(date)}`;
}
