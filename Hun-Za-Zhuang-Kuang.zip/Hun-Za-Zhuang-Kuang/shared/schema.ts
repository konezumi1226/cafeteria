import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const occupancyRecords = pgTable("occupancy_records", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  count: integer("count").notNull(),
  capacity: integer("capacity").notNull(),
});

export const insertOccupancyRecordSchema = createInsertSchema(occupancyRecords).pick({
  count: true,
  capacity: true,
});

export type InsertOccupancyRecord = z.infer<typeof insertOccupancyRecordSchema>;
export type OccupancyRecord = typeof occupancyRecords.$inferSelect;

export const flowEvents = pgTable("flow_events", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  isEntrance: boolean("is_entrance").notNull(),
  count: integer("count").notNull().default(1),
});

export const insertFlowEventSchema = createInsertSchema(flowEvents).pick({
  isEntrance: true,
  count: true,
});

export type InsertFlowEvent = z.infer<typeof insertFlowEventSchema>;
export type FlowEvent = typeof flowEvents.$inferSelect;

export const sensorStatus = pgTable("sensor_status", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  isOnline: boolean("is_online").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertSensorStatusSchema = createInsertSchema(sensorStatus).pick({
  name: true,
  isOnline: true,
});

export type InsertSensorStatus = z.infer<typeof insertSensorStatusSchema>;
export type SensorStatus = typeof sensorStatus.$inferSelect;

export const systemConfig = pgTable("system_config", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
});

export const insertSystemConfigSchema = createInsertSchema(systemConfig);

export type InsertSystemConfig = z.infer<typeof insertSystemConfigSchema>;
export type SystemConfig = typeof systemConfig.$inferSelect;
