import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertFlowEventSchema, insertOccupancyRecordSchema, insertSensorStatusSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Track all connected clients
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    
    // Send initial data on connection
    sendInitialData(ws);
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        if (data.type === 'sensor_data') {
          await handleSensorData(data.payload);
          broadcastUpdates();
        } else if (data.type === 'manual_update') {
          await handleManualUpdate(data.payload);
          broadcastUpdates();
        }
      } catch (error) {
        console.error('Error processing message:', error);
      }
    });
    
    ws.on('close', () => {
      clients.delete(ws);
    });
  });
  
  // Periodically broadcast updates to all clients
  setInterval(() => {
    broadcastUpdates();
  }, 5000);
  
  // API Routes
  app.get('/api/occupancy/current', async (req, res) => {
    const current = await storage.getCurrentOccupancy();
    if (!current) {
      return res.status(404).json({ message: 'No occupancy data found' });
    }
    res.json(current);
  });
  
  app.get('/api/occupancy/history', async (req, res) => {
    const hours = parseInt(req.query.hours as string) || 24;
    const history = await storage.getOccupancyHistory(hours);
    res.json(history);
  });
  
  app.get('/api/occupancy/daily-pattern', async (req, res) => {
    const pattern = await storage.getDailyOccupancyPattern();
    res.json(pattern);
  });
  
  app.get('/api/occupancy/weekly-pattern', async (req, res) => {
    const pattern = await storage.getWeeklyOccupancyPattern();
    res.json(pattern);
  });
  
  app.get('/api/flow/recent', async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 10;
    const events = await storage.getRecentFlowEvents(limit);
    res.json(events);
  });
  
  app.get('/api/flow/summary', async (req, res) => {
    const minutes = parseInt(req.query.minutes as string) || 10;
    const summary = await storage.getFlowRateSummary(minutes);
    res.json(summary);
  });
  
  app.get('/api/sensors/status', async (req, res) => {
    const statuses = await storage.getAllSensorStatus();
    res.json(statuses);
  });
  
  // Update flow event (simulating sensor input) - for admin or simulation
  app.post('/api/flow', async (req, res) => {
    try {
      const parsedData = insertFlowEventSchema.parse(req.body);
      const result = await storage.recordFlowEvent(parsedData);
      
      // Broadcast update to all connected clients
      broadcastUpdates();
      
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: 'Unknown error occurred' });
    }
  });
  
  // Manual occupancy update
  app.post('/api/occupancy', async (req, res) => {
    try {
      const parsedData = insertOccupancyRecordSchema.parse(req.body);
      const result = await storage.recordOccupancy(parsedData);
      
      // Broadcast update to all connected clients
      broadcastUpdates();
      
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: 'Unknown error occurred' });
    }
  });
  
  // Update sensor status
  app.post('/api/sensors/status', async (req, res) => {
    try {
      const parsedData = insertSensorStatusSchema.parse(req.body);
      const result = await storage.updateSensorStatus(parsedData.name, parsedData.isOnline);
      
      // Broadcast update to all connected clients
      broadcastUpdates();
      
      res.status(200).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: 'Unknown error occurred' });
    }
  });
  
  // Helper functions
  async function sendInitialData(ws: WebSocket) {
    if (ws.readyState === WebSocket.OPEN) {
      const currentOccupancy = await storage.getCurrentOccupancy();
      const recentFlow = await storage.getRecentFlowEvents(10);
      const flowSummary = await storage.getFlowRateSummary(10);
      const sensorStatuses = await storage.getAllSensorStatus();
      
      ws.send(JSON.stringify({
        type: 'initial_data',
        payload: {
          currentOccupancy,
          recentFlow,
          flowSummary,
          sensorStatuses,
        }
      }));
    }
  }
  
  async function broadcastUpdates() {
    const currentOccupancy = await storage.getCurrentOccupancy();
    const recentFlow = await storage.getRecentFlowEvents(10);
    const flowSummary = await storage.getFlowRateSummary(10);
    const sensorStatuses = await storage.getAllSensorStatus();
    
    const update = JSON.stringify({
      type: 'update',
      payload: {
        currentOccupancy,
        recentFlow,
        flowSummary,
        sensorStatuses,
        timestamp: new Date()
      }
    });
    
    for (const client of clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(update);
      }
    }
  }
  
  async function handleSensorData(payload: any) {
    if (payload.sensor === 'entrance') {
      await storage.recordFlowEvent({ isEntrance: true, count: payload.count || 1 });
      await storage.updateSensorStatus('entrance_sensor', true);
    } else if (payload.sensor === 'exit') {
      await storage.recordFlowEvent({ isEntrance: false, count: payload.count || 1 });
      await storage.updateSensorStatus('exit_sensor', true);
    }
  }
  
  async function handleManualUpdate(payload: any) {
    if (payload.type === 'occupancy' && typeof payload.count === 'number') {
      const capacity = parseInt(await storage.getConfigValue('cafeteria_capacity') || '200');
      await storage.recordOccupancy({ count: payload.count, capacity });
    }
  }

  return httpServer;
}
