import {
  users, type User, type InsertUser,
  occupancyRecords, type OccupancyRecord, type InsertOccupancyRecord,
  flowEvents, type FlowEvent, type InsertFlowEvent,
  sensorStatus, type SensorStatus, type InsertSensorStatus,
  systemConfig, type SystemConfig, type InsertSystemConfig
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, gt } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Occupancy operations
  getCurrentOccupancy(): Promise<OccupancyRecord | undefined>;
  getOccupancyHistory(hours?: number): Promise<OccupancyRecord[]>;
  getDailyOccupancyPattern(): Promise<{ hour: number; avgCount: number }[]>;
  getWeeklyOccupancyPattern(): Promise<{ day: number; avgCount: number }[]>;
  recordOccupancy(record: InsertOccupancyRecord): Promise<OccupancyRecord>;

  // Flow events operations
  recordFlowEvent(event: InsertFlowEvent): Promise<FlowEvent>;
  getRecentFlowEvents(limit?: number): Promise<FlowEvent[]>;
  getFlowRateSummary(minutes?: number): Promise<{
    entrances: number;
    exits: number;
    net: number;
  }>;

  // Sensor status operations
  getAllSensorStatus(): Promise<SensorStatus[]>;
  updateSensorStatus(name: string, isOnline: boolean): Promise<SensorStatus>;

  // System config operations
  getConfigValue(key: string): Promise<string | undefined>;
  setConfigValue(key: string, value: string): Promise<SystemConfig>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize with default sensor statuses and config values
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    try {
      // Check if any sensor statuses exist
      const existingSensors = await db.select().from(sensorStatus);
      if (existingSensors.length === 0) {
        // Initialize default sensor statuses
        await this.updateSensorStatus("entrance_sensor", true);
        await this.updateSensorStatus("exit_sensor", true);
      }

      // Check if any config values exist
      const existingConfigs = await db.select().from(systemConfig);
      if (existingConfigs.length === 0) {
        // Set default config values
        await this.setConfigValue("cafeteria_capacity", "200");
        await this.setConfigValue("low_congestion_threshold", "40");
        await this.setConfigValue("high_congestion_threshold", "80");
      }
      
      // Check if any occupancy records exist
      const existingOccupancy = await db.select().from(occupancyRecords);
      if (existingOccupancy.length === 0) {
        // Initialize with some occupancy (for demo)
        await this.recordOccupancy({ count: 138, capacity: 200 });
      }
    } catch (error) {
      console.error("Failed to initialize default data:", error);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Occupancy operations
  async getCurrentOccupancy(): Promise<OccupancyRecord | undefined> {
    const result = await db.select().from(occupancyRecords).orderBy(desc(occupancyRecords.timestamp)).limit(1);
    return result[0];
  }

  async getOccupancyHistory(hours: number = 24): Promise<OccupancyRecord[]> {
    const cutoff = new Date();
    cutoff.setHours(cutoff.getHours() - hours);
    
    return await db.select()
      .from(occupancyRecords)
      .where(gt(occupancyRecords.timestamp, cutoff))
      .orderBy(occupancyRecords.timestamp);
  }

  async getDailyOccupancyPattern(): Promise<{ hour: number; avgCount: number }[]> {
    const results = await db.select({
      hour: sql`EXTRACT(HOUR FROM ${occupancyRecords.timestamp})::int`,
      avgCount: sql`ROUND(AVG(${occupancyRecords.count}))::int`
    })
    .from(occupancyRecords)
    .groupBy(sql`EXTRACT(HOUR FROM ${occupancyRecords.timestamp})::int`);
    
    // Fill in missing hours with zeros
    const hourlyData = new Map<number, number>();
    results.forEach(result => {
      hourlyData.set(result.hour, result.avgCount);
    });
    
    const pattern: { hour: number; avgCount: number }[] = [];
    for (let hour = 0; hour < 24; hour++) {
      pattern.push({
        hour,
        avgCount: hourlyData.get(hour) || 0
      });
    }
    
    return pattern;
  }

  async getWeeklyOccupancyPattern(): Promise<{ day: number; avgCount: number }[]> {
    const results = await db.select({
      day: sql`EXTRACT(DOW FROM ${occupancyRecords.timestamp})::int`,
      avgCount: sql`ROUND(AVG(${occupancyRecords.count}))::int`
    })
    .from(occupancyRecords)
    .groupBy(sql`EXTRACT(DOW FROM ${occupancyRecords.timestamp})::int`);
    
    // Fill in missing days with zeros
    const dailyData = new Map<number, number>();
    results.forEach(result => {
      dailyData.set(result.day, result.avgCount);
    });
    
    const pattern: { day: number; avgCount: number }[] = [];
    for (let day = 0; day < 7; day++) {
      pattern.push({
        day,
        avgCount: dailyData.get(day) || 0
      });
    }
    
    return pattern;
  }

  async recordOccupancy(insertRecord: InsertOccupancyRecord): Promise<OccupancyRecord> {
    const result = await db.insert(occupancyRecords)
      .values({
        ...insertRecord,
        timestamp: new Date()
      })
      .returning();
      
    return result[0];
  }

  // Flow events operations
  async recordFlowEvent(insertEvent: InsertFlowEvent): Promise<FlowEvent> {
    // First insert the flow event
    const result = await db.insert(flowEvents)
      .values({
        ...insertEvent,
        timestamp: new Date()
      })
      .returning();
      
    // Then update current occupancy based on flow event
    const currentOccupancy = await this.getCurrentOccupancy();
    if (currentOccupancy) {
      const delta = insertEvent.isEntrance ? insertEvent.count : -insertEvent.count;
      const newCount = Math.max(0, currentOccupancy.count + delta);
      await this.recordOccupancy({
        count: newCount,
        capacity: currentOccupancy.capacity
      });
    }
    
    return result[0];
  }

  async getRecentFlowEvents(limit: number = 10): Promise<FlowEvent[]> {
    return await db.select()
      .from(flowEvents)
      .orderBy(desc(flowEvents.timestamp))
      .limit(limit);
  }

  async getFlowRateSummary(minutes: number = 10): Promise<{
    entrances: number;
    exits: number;
    net: number;
  }> {
    const cutoff = new Date();
    cutoff.setMinutes(cutoff.getMinutes() - minutes);
    
    const recentEvents = await db.select()
      .from(flowEvents)
      .where(gt(flowEvents.timestamp, cutoff));
    
    const entrances = recentEvents
      .filter(event => event.isEntrance)
      .reduce((sum, event) => sum + event.count, 0);
      
    const exits = recentEvents
      .filter(event => !event.isEntrance)
      .reduce((sum, event) => sum + event.count, 0);
    
    return {
      entrances,
      exits,
      net: entrances - exits
    };
  }

  // Sensor status operations
  async getAllSensorStatus(): Promise<SensorStatus[]> {
    return await db.select().from(sensorStatus);
  }

  async updateSensorStatus(name: string, isOnline: boolean): Promise<SensorStatus> {
    // Find if exists
    const existingStatus = await db.select()
      .from(sensorStatus)
      .where(eq(sensorStatus.name, name));
    
    if (existingStatus.length > 0) {
      // Update existing status
      const result = await db.update(sensorStatus)
        .set({
          isOnline,
          lastUpdated: new Date()
        })
        .where(eq(sensorStatus.name, name))
        .returning();
        
      return result[0];
    }
    
    // Create new status
    const result = await db.insert(sensorStatus)
      .values({
        name,
        isOnline,
        lastUpdated: new Date()
      })
      .returning();
      
    return result[0];
  }

  // System config operations
  async getConfigValue(key: string): Promise<string | undefined> {
    const result = await db.select()
      .from(systemConfig)
      .where(eq(systemConfig.key, key));
      
    return result[0]?.value;
  }

  async setConfigValue(key: string, value: string): Promise<SystemConfig> {
    // Find if exists
    const existingConfig = await db.select()
      .from(systemConfig)
      .where(eq(systemConfig.key, key));
    
    if (existingConfig.length > 0) {
      // Update existing config
      const result = await db.update(systemConfig)
        .set({ value })
        .where(eq(systemConfig.key, key))
        .returning();
        
      return result[0];
    }
    
    // Create new config
    const result = await db.insert(systemConfig)
      .values({ key, value })
      .returning();
      
    return result[0];
  }
}

export const storage = new DatabaseStorage();
